import React, { useState, useEffect } from "react";
import {
  X,
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  CheckCircle2,
  Sparkles,
  GraduationCap,
  ShieldCheck,
  Zap,
  ArrowRight,
  LogIn,
  UserPlus,
} from "lucide-react";
import { UserProfile, AuthAccount } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser?: UserProfile;
  onLoginSuccess: (user: UserProfile) => void;
  initialMode?: "signin" | "signup";
}

const OPTIONAL_SUBJECTS = [
  "Public Administration",
  "Political Science & IR (PSIR)",
  "Sociology",
  "Geography",
  "History",
  "Anthropology",
  "Philosophy",
  "Economics",
  "Law",
  "Psychology",
];

const TARGET_YEARS = ["UPSC CSE 2025", "UPSC CSE 2026", "UPSC CSE 2027", "UPSC CSE 2028"];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  initialMode = "signin",
}) => {
  const [mode, setMode] = useState<"signin" | "signup">(initialMode);
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // Sign In Form State
  const [signInEmail, setSignInEmail] = useState<string>(currentUser?.email || "");
  const [signInPassword, setSignInPassword] = useState<string>("");
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Keep signInEmail synced if currentUser changes
  useEffect(() => {
    if (currentUser?.email) {
      setSignInEmail(currentUser.email);
    }
  }, [currentUser?.email]);

  // Sign Up Form State
  const [signUpName, setSignUpName] = useState<string>("");
  const [signUpEmail, setSignUpEmail] = useState<string>("");
  const [signUpPassword, setSignUpPassword] = useState<string>("");
  const [signUpConfirmPassword, setSignUpConfirmPassword] = useState<string>("");
  const [signUpTarget, setSignUpTarget] = useState<string>("UPSC CSE 2026");
  const [signUpOptional, setSignUpOptional] = useState<string>("Public Administration");
  const [studyGoalHours, setStudyGoalHours] = useState<number>(6);

  // Validation / Message feedback
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!signInEmail.trim()) {
      setErrorMsg("Please enter your registered email address.");
      return;
    }
    if (!signInPassword) {
      setErrorMsg("Please enter your account password.");
      return;
    }

    try {
      // Check stored accounts in localStorage
      const stored = localStorage.getItem("bolt_upsc_accounts");
      const accounts: AuthAccount[] = stored ? JSON.parse(stored) : [];

      const existing = accounts.find(
        (a) => a.email.toLowerCase() === signInEmail.trim().toLowerCase()
      );

      if (existing) {
        const loggedInUser: UserProfile = {
          id: existing.id,
          name: existing.name,
          email: existing.email,
          target: existing.target,
          optionalSubject: existing.optionalSubject,
          studyStreakDays: 14,
          totalStudyHours: 180,
          questionsAttempted: 1600,
          mainsEvaluatedCount: 28,
          overallAccuracy: 74,
        };

        if (rememberMe) {
          localStorage.setItem("bolt_current_user", JSON.stringify(loggedInUser));
        }

        setSuccessMsg(`Welcome back, ${existing.name}!`);
        setTimeout(() => {
          onLoginSuccess(loggedInUser);
          onClose();
        }, 600);
      } else {
        // Allow instant public sign-in with default profile if account doesn't exist yet
        const defaultName = signInEmail.split("@")[0] || "Aspirant";
        const capitalizedName = defaultName.charAt(0).toUpperCase() + defaultName.slice(1);
        const loggedInUser: UserProfile = {
          id: "u-" + Date.now(),
          name: capitalizedName,
          email: signInEmail.trim(),
          target: "UPSC CSE 2026",
          optionalSubject: "Public Administration",
          studyStreakDays: 1,
          totalStudyHours: 2,
          questionsAttempted: 10,
          mainsEvaluatedCount: 1,
          overallAccuracy: 70,
        };

        // Save new account
        accounts.push({
          id: loggedInUser.id!,
          name: loggedInUser.name,
          email: loggedInUser.email!,
          target: loggedInUser.target,
          optionalSubject: loggedInUser.optionalSubject,
          createdAt: new Date().toISOString(),
        });
        localStorage.setItem("bolt_upsc_accounts", JSON.stringify(accounts));
        localStorage.setItem("bolt_current_user", JSON.stringify(loggedInUser));

        setSuccessMsg(`Account registered and signed in as ${loggedInUser.name}!`);
        setTimeout(() => {
          onLoginSuccess(loggedInUser);
          onClose();
        }, 600);
      }
    } catch (err: any) {
      setErrorMsg("Failed to sign in. Please try again.");
    }
  };

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!signUpName.trim()) {
      setErrorMsg("Please enter your real aspirant name.");
      return;
    }
    if (!signUpEmail.trim() || !signUpEmail.includes("@")) {
      setErrorMsg("Please provide a valid email address.");
      return;
    }
    if (signUpPassword.length < 6) {
      setErrorMsg("Password must be at least 6 characters long.");
      return;
    }
    if (signUpPassword !== signUpConfirmPassword) {
      setErrorMsg("Passwords do not match. Please verify.");
      return;
    }

    try {
      const stored = localStorage.getItem("bolt_upsc_accounts");
      const accounts: AuthAccount[] = stored ? JSON.parse(stored) : [];

      // Check if email already exists
      const emailExists = accounts.some(
        (a) => a.email.toLowerCase() === signUpEmail.trim().toLowerCase()
      );
      if (emailExists) {
        setErrorMsg("An account with this email already exists. Please Sign In.");
        return;
      }

      const newAccount: AuthAccount = {
        id: "acc-" + Date.now(),
        name: signUpName.trim(),
        email: signUpEmail.trim(),
        password: signUpPassword,
        target: signUpTarget,
        optionalSubject: signUpOptional,
        createdAt: new Date().toISOString(),
      };

      accounts.push(newAccount);
      localStorage.setItem("bolt_upsc_accounts", JSON.stringify(accounts));

      const newUserProfile: UserProfile = {
        id: newAccount.id,
        name: newAccount.name,
        email: newAccount.email,
        target: newAccount.target,
        optionalSubject: newAccount.optionalSubject,
        studyStreakDays: 1,
        totalStudyHours: studyGoalHours,
        questionsAttempted: 0,
        mainsEvaluatedCount: 0,
        overallAccuracy: 0,
      };

      localStorage.setItem("bolt_current_user", JSON.stringify(newUserProfile));

      setSuccessMsg(`Account successfully created for ${newAccount.name}! Loading dashboard...`);
      setTimeout(() => {
        onLoginSuccess(newUserProfile);
        onClose();
      }, 700);
    } catch (err: any) {
      setErrorMsg("Failed to create account. Please retry.");
    }
  };

  const handleDemoSignIn = (demoName: string, demoOptional: string) => {
    const demoUser: UserProfile = {
      id: "demo-" + Date.now(),
      name: demoName,
      email: `${demoName.toLowerCase().replace(/\s+/g, ".")}@upsc-aspirant.org`,
      target: "UPSC CSE 2026",
      optionalSubject: demoOptional,
      studyStreakDays: 16,
      totalStudyHours: 210,
      questionsAttempted: 1850,
      mainsEvaluatedCount: 32,
      overallAccuracy: 76,
    };
    localStorage.setItem("bolt_current_user", JSON.stringify(demoUser));
    setSuccessMsg(`Welcome, ${demoUser.name}! Loaded public demo profile.`);
    setTimeout(() => {
      onLoginSuccess(demoUser);
      onClose();
    }, 500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0e1422] rounded-2xl border border-[#1e293b] max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl relative my-8">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-800/60 transition-colors"
          title="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Branding */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
            <Zap className="w-6 h-6 text-white fill-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-bold text-white text-lg font-['Outfit']">
                BOLT UPSC
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-bold border border-blue-500/30 uppercase tracking-wider">
                Public Access
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Personalized UPSC Civil Services & Public Administration Preparation
            </p>
          </div>
        </div>

        {/* Tab Switcher: Sign In vs Sign Up */}
        <div className="flex rounded-xl bg-[#151c2c] p-1 border border-slate-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => {
              setMode("signin");
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2 rounded-lg flex items-center justify-center space-x-2 transition-all ${
              mode === "signin"
                ? "bg-blue-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <LogIn className="w-4 h-4" />
            <span>Sign In</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setMode("signup");
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`flex-1 py-2 rounded-lg flex items-center justify-center space-x-2 transition-all ${
              mode === "signup"
                ? "bg-blue-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>Create Account</span>
          </button>
        </div>

        {/* Alerts / Error messages */}
        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/50 text-red-300 text-xs flex items-center space-x-2">
            <span className="w-1.5 h-1.5 rounded-full bg-red-400 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/50 text-emerald-300 text-xs flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* SIGN IN FORM */}
        {mode === "signin" ? (
          <form onSubmit={handleSignIn} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
                <Mail className="w-3.5 h-3.5 text-blue-400" />
                <span>Email Address</span>
              </label>
              <input
                type="email"
                required
                value={signInEmail}
                onChange={(e) => setSignInEmail(e.target.value)}
                placeholder="e.g. aspirant@upsc.in"
                className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span className="flex items-center space-x-1.5">
                  <Lock className="w-3.5 h-3.5 text-blue-400" />
                  <span>Password</span>
                </span>
                <span className="text-[11px] text-slate-500 font-normal">Min 6 characters</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={signInPassword}
                  onChange={(e) => setSignInPassword(e.target.value)}
                  placeholder="Enter your account password"
                  className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-blue-500 pr-10 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-blue-600 focus:ring-0"
                />
                <span>Remember me on this device</span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center space-x-2"
            >
              <span>Sign In to BOLT</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Quick Demo Aspirant Access */}
            <div className="pt-3 border-t border-slate-800 space-y-2">
              <p className="text-[11px] text-center text-slate-400 font-medium">
                Or explore instantly with pre-loaded profiles:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleDemoSignIn("Pooja Sharma", "Public Administration")}
                  className="p-2 rounded-xl bg-[#162033] hover:bg-[#1f2d48] border border-slate-800 text-xs text-left transition-colors"
                >
                  <p className="font-bold text-slate-200">Pooja Sharma</p>
                  <p className="text-[10px] text-blue-400 font-medium">Pub Admin • 2026</p>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoSignIn("Arjun Verma", "Political Science & IR (PSIR)")}
                  className="p-2 rounded-xl bg-[#162033] hover:bg-[#1f2d48] border border-slate-800 text-xs text-left transition-colors"
                >
                  <p className="font-bold text-slate-200">Arjun Verma</p>
                  <p className="text-[10px] text-purple-400 font-medium">PSIR • 2026</p>
                </button>
              </div>
            </div>
          </form>
        ) : (
          /* SIGN UP FORM */
          <form onSubmit={handleSignUp} className="space-y-3.5">
            {/* Full Name */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
                <User className="w-3.5 h-3.5 text-blue-400" />
                <span>Your Name (Removes Fixed Name)</span>
              </label>
              <input
                type="text"
                required
                value={signUpName}
                onChange={(e) => setSignUpName(e.target.value)}
                placeholder="e.g. Rahul Sen / Sneha Reddy"
                className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Email */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
                <Mail className="w-3.5 h-3.5 text-blue-400" />
                <span>Email Address</span>
              </label>
              <input
                type="email"
                required
                value={signUpEmail}
                onChange={(e) => setSignUpEmail(e.target.value)}
                placeholder="e.g. rahul.sen@upsc.org"
                className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Target Year & Optional Subject in 2 cols */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Target Year</label>
                <select
                  value={signUpTarget}
                  onChange={(e) => setSignUpTarget(e.target.value)}
                  className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  {TARGET_YEARS.map((yr) => (
                    <option key={yr} value={yr} className="bg-[#121826]">
                      {yr}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Optional Subject</label>
                <select
                  value={signUpOptional}
                  onChange={(e) => setSignUpOptional(e.target.value)}
                  className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                >
                  {OPTIONAL_SUBJECTS.map((sub) => (
                    <option key={sub} value={sub} className="bg-[#121826]">
                      {sub}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Password & Confirm Password */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Password</label>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={signUpPassword}
                  onChange={(e) => setSignUpPassword(e.target.value)}
                  placeholder="At least 6 chars"
                  className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Confirm Password</label>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={signUpConfirmPassword}
                  onChange={(e) => setSignUpConfirmPassword(e.target.value)}
                  placeholder="Confirm password"
                  className="w-full bg-[#121826] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 mt-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 transition-all flex items-center justify-center space-x-2"
            >
              <span>Create Account & Start Preparing</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
